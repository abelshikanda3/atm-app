



import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream; 
import java.io.FileNotFoundException;  

import java.util.*; 
import java.sql.*;

import javafx.application.Application; 
import static javafx.application.Application.launch;

import javafx.geometry.Insets; 
import javafx.geometry.Pos; 
import javafx.scene.Scene;
import javafx.stage.Stage;

import javafx.scene.control.Button; 
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonBar.ButtonData;

import javafx.scene.text.Font;  
import javafx.scene.text.FontWeight;
import javafx.scene.paint.Color;
import javafx.scene.text.Text; 

import javafx.scene.control.TextField; 
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.PasswordField; 
import javafx.scene.control.Control;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Separator;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;

import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.BorderPane; 
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.FlowPane;

import javafx.collections.ObservableList;
import javafx.collections.FXCollections;

import javafx.event.EventHandler;
import javafx.event.ActionEvent;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.Group;  
import javafx.scene.chart.*;

import javafx.scene.input.MouseEvent;

 


public class atmimpl extends Application implements atm {
	
	Connection con = null;
	String db_url = "jdbc:mysql://localhost/accounts";
	String USER = "root";
	String PASS = "";
	
	
	
		
		
	public atmimpl () {}
	
	public void withdraw(){
		
			launch();
	}
		
	
	
	public void deposit() {
		
		launch();
	}
	
	public void account() {
		
			launch();
	}
		public List<String> foraccounts = new ArrayList<>();
		public Map<String, List<String>> accdet = new LinkedHashMap<>();
	
	public void start(Stage stage) {
		
		
		
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(db_url, USER, PASS);
		}catch(ClassNotFoundException ex){
			System.out.println("ERROR! Unable to load Driver class");
			System.exit(1);
		}catch(SQLException se){
				se.printStackTrace();
		}
		
		GridPane gp = new GridPane();
		gp.setPadding(new Insets(10, 10, 10, 10));
		gp.setVgap(10);
		gp.setHgap(10);
		gp.setPrefSize(500, 300);
		gp.setStyle("-fx-background-color: #5F9EA0;");
		gp.setAlignment(Pos.CENTER);
		
		Text Account = new Text("Account");
		Text Name = new Text("Name");
		Text No = new Text("Acc No.");
		Text Balance = new Text("Balance");
		
		
		Text Success = new Text("SUCCESS!!");
		Button home = new Button("Home");
		home.setStyle("-fx-background-color: #2F4F4F; -fx-text-fill: White;");
		home.setOnAction( e -> {
			Scene s = new Scene(gp);
			stage.setTitle("Home");
			stage.setScene(s);
			stage.show();
		});
		
		Text Amount = new Text("Amount to withdraw");
		TextField amount = new TextField();
		amount.setStyle("-fx-font: normal bold 15px 'serif' ");
		Button ok = new Button("Withdraw");
		ok.setStyle("-fx-background-color: #2F4F4F; -fx-text-fill: White;");
		ok.setOnAction( e -> {
			System.out.println("withdrawing");
			try{
				String sql = "INSERT INTO records"+"(Withdrawn) VALUES (?)";
				final PreparedStatement stmt = con.prepareStatement(sql);
				stmt.setString(1, amount.getText());
				//stmt.setString(1, Fname.getText());
				stmt.executeUpdate(); 
				
				/*String sqls = "SELECT * FORM accuonts WHERE Bal";
				final PreparedStatement stmts = con.prepareStatement(sql);
				
				stmts.executeUpdate();*/
				
			}catch(SQLException se){
				se.printStackTrace();
			}
			gp.getChildren().clear();
			gp.add(Success, 1, 1);
			gp.add(home, 1, 2);
			
		});
		
		/*ObservableList<String> acc = new FXCollections.observableArrayList(
		"Account1",
		"Account2"
		);*/
		ComboBox<String> cbacc = new ComboBox<>();
		/*ObservableList<String> accf = FXCollections.observableArrayList(
		"AccountName1",
		"AccountName2"
		);*/
		TextField tfaccf = new TextField();
		//account.setStyle("-fx-font: normal bold 15px 'serif' ");
		TextField name = new TextField();
		name.setStyle("-fx-font: normal bold 15px 'serif' ");
		TextField no = new TextField();
		no.setStyle("-fx-font: normal bold 15px 'serif' ");
		TextField balance = new TextField();
		balance.setStyle("-fx-font: normal bold 15px 'serif' ");
		
		Button with = new Button("withdraw");
		with.setStyle("-fx-background-color: #2F4F4F; -fx-text-fill: White;");
		with.setOnAction( e -> {
			gp.getChildren().clear();
			gp.add(Amount, 1, 1);
			gp.add(amount, 1, 2);
			gp.add(ok, 1, 3);
		});
		
		Button depo = new Button("deposit");
		depo.setStyle("-fx-background-color: #2F4F4F; -fx-text-fill: White;");
		depo.setOnAction( e -> {});
		
		gp.add(Account, 0, 0);
		gp.add(Name, 0, 1);
		gp.add(No, 0, 2);
		gp.add(Balance, 0, 3);
		gp.add(cbacc, 1, 0);
		
		gp.add(name, 1, 1);
		gp.add(no, 1, 2);
		gp.add(balance, 1, 3);
		gp.add(with, 1, 4);
		gp.add(depo, 2, 4);
		
		
		
		Scene s = new Scene(gp);
		stage.setTitle("Name");
		stage.setScene(s);
		stage.show();
		
		
		
	}
}